/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.ihsa.zkintro;

import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zk.ui.util.Clients;
import org.zkoss.zul.Borderlayout;
import org.zkoss.zul.Button;
import org.zkoss.zul.Center;
import org.zkoss.zul.Div;
import org.zkoss.zul.Image;
import org.zkoss.zul.Label;
import org.zkoss.zul.North;
import org.zkoss.zul.Panel;
import org.zkoss.zul.Panelchildren;
import org.zkoss.zul.Textbox;
import org.zkoss.zul.Toolbarbutton;
import org.zkoss.zul.Vbox;
import org.zkoss.zul.Vlayout;
import org.zkoss.zul.West;
import org.zkoss.zul.Window;

/**
 *
 * @author mrojas
 */
public class Main extends Window {
    
    private Borderlayout mainLayout;
    private Center centerPanel;
    private West westPanel;
    private North northPanel;
    
    public Main() {
        zkInit();
    }

    private void zkInit() {
        setWidth("100%");
        setHeight("100%");
        setBorder("0");
        buildMainLayout();
    }
    
    private void buildMainLayout() {
        mainLayout = new Borderlayout();
        mainLayout.setParent(this);
//        mainLayout.setSclass("complex-layout");
        
        northPanel = buildNorth();
        northPanel.setParent(mainLayout);
        
        centerPanel = buildCenter();
        mainLayout.appendChild(centerPanel);
        
        westPanel = buildWest();
        mainLayout.appendChild(westPanel);
    }
    
    private North buildNorth() {
        northPanel = new North();
        northPanel.setSize("90px");
        northPanel.setBorder("0");
        
        Div container = new Div();
        container.setParent(northPanel);
        
        Image logo = new Image("http://www.zkoss.org/zkdemo/images/ZK-Logo.gif");
//        logo.setSclass("complex-layout-header-img");
        
        Label label = new Label("ZK Project");
//        label.setSclass("complex-layout-header-label");
        
        Div internal = new Div();
        internal.setStyle("float:right");
        
        Textbox searchBox = new Textbox();
        searchBox.setParent(internal);
                
        Button searchBtn = new Button("Search");
        searchBtn.setParent(internal);
        searchBtn.setSclass("btn-primary");
        
        logo.setParent(container);
        label.setParent(container);
        internal.setParent(container);
        
        return northPanel;
    }

    
    private West buildWest() {
        westPanel = new West();
        westPanel.setBorder("0");
        westPanel.setWidth("200px");
        westPanel.setSplittable(true);
        westPanel.setMargins("0,5,0,0");
        westPanel.setHflex("true");
        westPanel.setVflex("true");
        
        Vlayout container = new Vlayout();
        container.setSpacing("0");
        
        Panel panel = new Panel();
        panel.setWidth("100%");
        panel.setTitle("Navigation");
        panel.setParent(container);
        
        Panelchildren children = new Panelchildren();
        children.setStyle("padding:5px");
        children.setParent(panel);
        
        Vbox botonera = new Vbox();
        botonera.setParent(children);
        botonera.setClass("btn-group-vertical");
        
        Toolbarbutton btn1 = new Toolbarbutton("Home");
        btn1.setParent(botonera);
        
        container.setParent(westPanel);
        return westPanel;
    }
    
    private Center buildCenter() {
        centerPanel = new Center();
        centerPanel.setHflex("true");
        centerPanel.setBorder("0");
        
        Button boton = new Button();
        //boton.setMold("trendy");
        boton.setTooltiptext("Don't click on me ;)");
        boton.setImage("go-home.svg");
        boton.addEventListener(Events.ON_CLICK, new EventListener<Event>() {

            public void onEvent(Event t) throws Exception {
                Clients.alert("You've clicked on the button.");
            }
        });
        centerPanel.appendChild(boton);
        
        return centerPanel;
    }    
}
